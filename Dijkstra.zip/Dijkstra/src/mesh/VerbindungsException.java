package mesh;

public class VerbindungsException extends Exception {

	private static final long serialVersionUID = 1L;

	VerbindungsException(){
		super("Verbdindungs fehler!");
	}

}
