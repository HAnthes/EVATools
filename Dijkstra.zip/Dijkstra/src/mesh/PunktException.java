package mesh;

public class PunktException extends Exception {
 
	private static final long serialVersionUID = 1L;

	PunktException(){
		super("Punkt fehler!");
	}
	
  	
}
